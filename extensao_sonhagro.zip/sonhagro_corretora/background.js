chrome.runtime.onInstalled.addListener(function() {
  console.log("Extensão de Login Automático instalada. Sonhagro Corretora.");
});
