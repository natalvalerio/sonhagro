from flask import Flask, render_template, jsonify, request, session, redirect, url_for, Response, stream_with_context, send_file
from werkzeug.exceptions import NotFound
from io import StringIO
import io
import os
import sqlite3
import csv
import datetime
from flask_session import Session
from flask_cors import CORS
#api
from api import selecionar, executar_sql
#teo
import matplotlib.pyplot as plt
from io import BytesIO
import base64

#----------------------------------------------------------------
# Sequencia da aplicação flask
#----------------------------------------------------------------

app = Flask(__name__, static_url_path='/static')
CORS(app, origins="*") # Configuração do CORS

# banco de dados
banco='../dados/banco.db'

# chave para cookies
app.secret_key = 'kdjfsdklfjdfjkfjlkdjfalkjdalsjk'

# Configuração da extensão flask-session
tempo = 30
app.config['SESSION_TYPE'] = 'filesystem'
app.config['SESSION_PERMANENT'] = True
app.config['PERMANENT_SESSION_LIFETIME'] = datetime.timedelta(minutes=tempo)
Session(app)

#--------------------------------------------------------------------
# Rota para servir arquivos estáticos (HTML, imagens, etc.) a partir de uma pasta
@app.route('/static/<path:filename>')
def servir_arquivos_estaticos(filename):
    return send_from_directory('static', filename)


#--------------------------------------------------------------------
# API
#--------------------------------------------------------------------
'''
@app.route('/api/select/<table>/<campo>/<busca>', methods=['GET'])
'''
@app.route('/api/select/<table>', defaults={'campo': None, 'busca': None}, methods=['GET'])
@app.route('/api/select/<table>/<campo>/<busca>', methods=['GET'])
def api_select(table,campo,busca):
    '''
    # Se campo ou busca forem None, significa que eles não foram fornecidos na URL
    if campo is None or busca is None:
        # Chame a função selecionar do arquivo api.py sem especificar campo e busca
        return selecionar(table)
    else:
        # Chame a função selecionar do arquivo api.py passando todos os parâmetros
        return selecionar(table, campo, busca)
    '''    
    return selecionar(table, campo, busca)
    
#---------api executar-----------------------------------------------------------
@app.route('/api/sql', methods=['POST'])
def api_sql(): 
    return executar_sql()


#--------------------------------------------------------------------
# Função para verificar as credenciais do usuário
def verificar_credenciais(nome, senha):
    # Conecta-se ao banco de dados SQLite
    conn, c = connect_database(banco)

    # Verifica se o usuário existe na tabela "usuarios"
    c.execute("SELECT nivel FROM usuarios WHERE nome = ? AND senha = ?", (nome, senha))

    resultado = c.fetchone()

    # Fecha a conexão com o banco de dados
    conn.close()

    if resultado is not None:
        return resultado[0]  # Retorna o nível do usuário se as credenciais estiverem corretas
    else:
        return None

#-----------------------------------------------------------------------        
def verificar_acesso(): 
    if 'nome' not in session:  # Verifica se o usuário está logado
        session['url_completo'] = request.url
        return redirect(url_for('login'))  # Redireciona para a página de login
    else:
        nivel = session['nivel']  # Obtém o nível de acesso do usuário
        rota = request.path  # Obtém a rota atual
        if rota == '/home' and nivel > 1:
            return redirect(url_for('index'))  # Redireciona para a rota '/'
        elif rota == '/config_tabelas' and nivel > 0:
            return redirect(url_for('index'))  # Redireciona para a rota '/'
        elif rota == '/delete_table' and nivel > 0:
            return redirect(url_for('index'))  # Redireciona para a rota '/'
        elif rota == '/create_table' and nivel > 0:
            return redirect(url_for('index'))  # Redireciona para a rota '/'
        elif rota.startswith('/crud/') and nivel > 1:
            return redirect(url_for('index'))  # Redireciona para a rota '/'
        elif rota.startswith('/crud_add/') and nivel > 3:
            return redirect(url_for('index'))  # Redireciona para a rota '/'
        elif rota.startswith('/crud_edit/') and nivel > 2:
            return redirect(url_for('index'))  # Redireciona para a rota '/'
        elif rota == '/delete_record_route' and nivel > 2:
            return redirect(url_for('index'))  # Redireciona para a rota '/'
        elif rota.startswith('/crud/usuarios') and nivel > 0:
            return redirect(url_for('index'))  # Redireciona para a rota '/'
        elif rota.startswith('/crud/TEO') and nivel > 0:
            return redirect(url_for('index'))  # Redireciona para a rota '/'
        elif rota == '/teo' and nivel > 0:
            return redirect(url_for('index'))  # Redireciona para a rota '/'

    return None  # Retorna None se o acesso for permitido

#--------------------------------------------------------
# Rota para a página de login
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        nome = request.form['nome']
        senha = request.form['senha']

        nivel = verificar_credenciais(nome, senha)

        if nivel is not None:
            # Define a sessão para o usuário autenticado
            session['nome'] = nome
            session['nivel'] = nivel
            expiration_time = datetime.datetime.now().timestamp() + app.config['PERMANENT_SESSION_LIFETIME'].total_seconds()
            session['expiration_time'] = expiration_time
            
            #para envio de email confirmando o login.
            #envio(nome)

            # Verifica se há um endereço original na sessão
            next_url = session.get('next_url')
            
            if next_url:
                # Remove o endereço original da sessão
                session.pop('next_url')
                return redirect(next_url)
            else:
                return redirect(url_for('index'))
        else:
            return render_template('login.html', error=True)

    # Redireciona para a página de login e armazena o endereço original
    session['next_url'] = request.referrer
    return render_template('login.html', error=False)

#-----------------------------------------------------
# Rota para a página inicial
@app.route('/')
def index():
    if 'nome' in session:
        nome =  session['nome']
        nivel = session['nivel']
        if 'url_completo' in session:
            url_completo = session['url_completo']
            session.pop('url_completo')
            return redirect(url_completo)
        return render_template('index.html', nome=nome, nivel=nivel)

    # Redireciona para a página de login
    return redirect(url_for('login'))


#--------------------------------------------------------
# Rota para fazer logout
@app.route('/logout')
def logout():
    session.clear()  # Limpa os dados da sessão
    return redirect(url_for('login'))

#--------------------------------------------------------
# tratamento de rotas inesistentes
#@app.errorhandler(NotFound)
#def handle_not_found_error(error):
#    return redirect(url_for('index'))
    
#--------------------------------------------------------
@app.errorhandler(404)
def handle_not_found_error(e):
    return render_template('erro404.html'), 404
    
#--------------------------------------------------------
@app.errorhandler(405)
def handle_method_not_allowed_error(e):
    return render_template('erro404.html'), 404
    
#--------------------------------------------------------
@app.route('/erro404', endpoint='erro404')
def erro404():
    return render_template('erro404.html')

#--------------------------------------------------------
@app.route('/session_timer')
def session_timer():
    expiration_time = session.get('expiration_time')
    if expiration_time:
        time_left = max(expiration_time - datetime.datetime.now().timestamp(), 0)
        minutes = int(time_left // 60)
        seconds = int(time_left % 60)
        return jsonify({'minutes': minutes, 'seconds': seconds})
    return jsonify({'minutes': 0, 'seconds': 0})
    
#--------------------------------------------------------
# Função para conectar ao banco de dados SQLite
def connect_database(database):
    conn = sqlite3.connect(database)
    c = conn.cursor()
    return conn, c

#--------------------------------------------------------
def get_table_names(conn, c):
    c.execute("SELECT name FROM sqlite_master WHERE type='table'")
    table_names = [row[0] for row in c.fetchall()]

    # Remover a tabela 'sqlite_sequence' da lista de tabelas, se estiver presente
    if 'sqlite_sequence' in table_names:
        table_names.remove('sqlite_sequence')

    return table_names

#--------------------------------------------------------
# Função para obter todos os registros de uma tabela
def get_all_records(conn, c, table_name):
    c.execute(f"SELECT * FROM {table_name} ORDER BY id DESC")
    records = c.fetchall()
    return records

#--------------------------------------------------------
# Função para obter um registro específico de uma tabela
def get_record(conn, c, table_name, record_id):
    c.execute(f"SELECT * FROM {table_name} WHERE id=? ORDER BY id DESC", (record_id,))
    record = c.fetchone()
    return record

#--------------------------------------------------------
# Função para inserir um registro em uma tabela
def insert_record(conn, c, table_name, nome, idade):
    c.execute(f"INSERT INTO {table_name} (nome, idade) VALUES (?, ?)", (nome, idade))
    conn.commit()

#--------------------------------------------------------
# Função para atualizar um registro em uma tabela
def update_record(conn, c, table_name, record_id, nome, idade):
    c.execute(f"UPDATE {table_name} SET nome=?, idade=? WHERE id=?", (nome, idade, record_id))
    conn.commit()

#--------------------------------------------------------
# Função para excluir um registro de uma tabela
def delete_record(conn, c, table_name, record_id):
    c.execute(f"DELETE FROM {table_name} WHERE id=?", (record_id,))
    conn.commit()

#--------------------------------------------------------
# Função para pesquisar registros em uma tabela
def search_records(conn, c, table_name, termo):
    # Executa uma consulta SQL com o termo de busca em cada campo da tabela
    query = f"SELECT * FROM {table_name} WHERE "
    columns_query = []
    for column in c.execute(f"PRAGMA table_info({table_name})"):
        columns_query.append(f"{column[1]} LIKE '%{termo}%'")
    query += " OR ".join(columns_query)
    
    query = query + " ORDER BY id DESC"
    
    # Executa a consulta e obtém os registros correspondentes
    c.execute(query)
    records = c.fetchall()
    
    return records

#--------------------------------------------------------
# rota de pesquisa ou busca ou procura    
@app.route('/search/<table_name>', methods=['POST'])
def search(table_name):
    # Obtém o termo de busca do formulário
    termo = request.form['termo']

    # Conecta-se ao banco de dados SQLite
    conn, c = connect_database(banco)

    # Executa uma consulta SQL com o termo de busca
    records = search_records(conn, c, table_name, termo)

    # Fecha a conexão com o banco de dados
    conn.close()

    return render_template('crud.html', table_name=table_name, records=records)

#--------------------------------------------------------
@app.route('/home')
def home():
    # verificação de login de acesso
    redirecionar = verificar_acesso()
    if redirecionar:
        return redirecionar
        
    # Conecta-se ao banco de dados SQLite
    conn, c = connect_database(banco)

    # Obtém todas as tabelas do banco de dados
    table_names = get_table_names(conn, c)

    # Fecha a conexão com o banco de dados
    conn.close()

    selected_table = request.args.get('table_name')  # Obtém a tabela selecionada, se houver

    return render_template('home.html', table_names=table_names, selected_table=selected_table)


#--------------------------------------------------------
@app.route('/select_table', methods=['POST'])
def select_table():
    # Obtém o nome da tabela selecionada do formulário
    table_name = request.form['table_name']

    return redirect(f'/crud/{table_name}')

#--------------------------------------------------------
@app.route('/crud/<table_name>')
def crud(table_name):
    try:
        # verificação de login de acesso
        redirecionar = verificar_acesso()
        if redirecionar:
            return redirecionar

    
        # Conecta-se ao banco de dados SQLite
        conn, c = connect_database(banco)
    
        # Obtém todos os registros da tabela
        records = get_all_records(conn, c, table_name)
        
        # Obtém as informações da tabela
        c.execute(f"PRAGMA table_info({table_name})")
        table_info = c.fetchall()
    
        # Fecha a conexão com o banco de dados
        conn.close()
    
        return render_template('crud.html', table_name=table_name, records=records, table_info=table_info)
    
    except: #sqlite3.OperationalError:
        # Se ocorrer um erro de tabela não encontrada, redirecione para a página de erro 404
        return redirect(url_for('erro404'))

#--------------------------------------------------------
@app.route('/crud_add/<table_name>')
def crud_add(table_name):
    # verificação de login de acesso
    redirecionar = verificar_acesso()
    if redirecionar:
        return redirecionar
    
    if 'nome' in session:
        nome = session['nome']
        nivel = session['nivel']

    # Conecta-se ao banco de dados SQLite
    conn, c = connect_database(banco)

    # Obtém as informações da tabela
    c.execute(f"PRAGMA table_info({table_name})")
    table_info = c.fetchall()

    # Fecha a conexão com o banco de dados
    conn.close()

    return render_template('crud_add.html', table_name=table_name, table_info=table_info, nome=nome, nivel=nivel)

#--------------------------------------------------------
@app.route('/add_record/<table_name>', methods=['POST'])
def add_record(table_name):
    # Obtém os dados do formulário
    data = {}
    for field in request.form:
        if field != 'table_name':
            data[field] = request.form[field]

    # Conecta-se ao banco de dados SQLite
    conn, c = connect_database(banco)

    # Insere o registro na tabela
    placeholders = ','.join(['?'] * len(data))
    values = tuple(data.values())
    c.execute(f"INSERT INTO {table_name} ({','.join(data.keys())}) VALUES ({placeholders})", values)

    # Salva as alterações e fecha a conexão com o banco de dados
    conn.commit()
    conn.close()

    return redirect(f'/crud/{table_name}')

#--------------------------------------------------------
@app.route('/crud_edit/<table_name>/<int:record_id>')
def crud_edit(table_name, record_id):
    # verificação de login de acesso
    redirecionar = verificar_acesso()
    if redirecionar:
        return redirecionar
        
    if 'nome' in session:
        nome = session['nome']
        nivel = session['nivel']

    # Conecta-se ao banco de dados SQLite
    conn, c = connect_database(banco)

    # Obtém as informações da tabela
    c.execute(f"PRAGMA table_info({table_name})")
    table_info = c.fetchall()

    # Obtém o registro específico da tabela
    record = get_record(conn, c, table_name, record_id)

    # Fecha a conexão com o banco de dados
    conn.close()

    return render_template('crud_edit.html', table_name=table_name, table_info=table_info, record=record, nome=nome, nivel=nivel)

#--------------------------------------------------------
@app.route('/edit_record/<table_name>/<int:record_id>', methods=['POST'])
def edit_record(table_name, record_id):
    # Obtém os dados do formulário
    data = {}
    for field in request.form:
        if field != 'table_name':
            data[field] = request.form[field]

    # Conecta-se ao banco de dados SQLite
    conn, c = connect_database(banco)

    # Atualiza o registro na tabela
    placeholders = ','.join([f"{key} = ?" for key in data])
    values = tuple(data.values()) + (record_id,)
    c.execute(f"UPDATE {table_name} SET {placeholders} WHERE id=?", values)

    # Salva as alterações e fecha a conexão com o banco de dados
    conn.commit()
    conn.close()

    return redirect(f'/crud/{table_name}')

#--------------------------------------------------------
@app.route('/delete_record_route/<table_name>/<int:record_id>')
def delete_record_route(table_name, record_id):
    # Conecta-se ao banco de dados SQLite
    conn, c = connect_database(banco)

    # Deleta o registro da tabela
    delete_record(conn, c, table_name, record_id)

    # Fecha a conexão com o banco de dados
    conn.close()

    return redirect(f'/crud/{table_name}')

#--------------------------------------------------------
@app.route('/create_table', methods=['GET', 'POST'])
def create_table():
    # verificação de login de acesso
    redirecionar = verificar_acesso()
    if redirecionar:
        return redirecionar

    if request.method == 'POST':
        # Obtém o nome da tabela do formulário
        table_name = request.form['table_name']

        # Obtém os campos e tipos de campos do formulário
        fields = []
        field_count = len(request.form) // 2  # Divide por 2 porque cada campo tem um nome e um tipo associado
        for i in range(field_count):
            field_name = request.form[f'field_name_{i}']
            field_type = request.form[f'field_type_{i}']
            fields.append((field_name, field_type))

        # Conecta-se ao banco de dados SQLite
        conn, c = connect_database(banco)

        # Cria a tabela com os campos fornecidos
        create_table_query = f"CREATE TABLE {table_name} (id INTEGER PRIMARY KEY AUTOINCREMENT"
        for field in fields:
            field_name, field_type = field
            create_table_query += f", {field_name} {field_type}"
        create_table_query += ")"
        c.execute(create_table_query)

        # Salva as alterações e fecha a conexão com o banco de dados
        conn.commit()
        conn.close()

        return redirect('/config_tabelas')

    return render_template('create_table.html')

#--------------------------------------------------------    
# Rota para lidar com a exclusão de tabela
@app.route('/delete_table', methods=['POST'])
def delete_table():
    # verificação de login de acesso
    redirecionar = verificar_acesso()
    if redirecionar:
        return redirecionar

    table_name = request.form.get('table_name')
    #table_name = request.args.get('table_name') 
    
    #if not confirmDelete():
    #   return redirect('/')
             
    # Conecta-se ao banco de dados SQLite
    conn, c = connect_database(banco)

    # Exclui a tabela
    c.execute(f"DROP TABLE IF EXISTS {table_name}")    

    print(f"DROP TABLE {table_name}")

    # Salva as alterações e fecha a conexão com o banco de dados
    conn.commit()
    conn.close()

    return redirect('/')

#--------------------------------------------------------    
# Rota para excluir uma tabela
@app.route('/del_table/<table_name>')
def del_table(table_name):
    # verificação de login de acesso
    redirecionar = verificar_acesso()
    if redirecionar:
        return redirecionar

    # Conecta-se ao banco de dados SQLite
    conn, c = connect_database(banco)

    # Executa o comando SQL para excluir a tabela
    c.execute(f"DROP TABLE IF EXISTS {table_name}")  

    # Obtém todas as tabelas do banco de dados (após a exclusão)
    table_names = get_table_names(conn, c)

    # Fecha a conexão com o banco de dados
    conn.close()

    return render_template('config_tabelas.html', table_names=table_names)

#--------------------------------------------------------    
@app.route('/edit_table/<table_name>', methods=['GET', 'POST'])
def edit_table(table_name):
    # verificação de login de acesso
    redirecionar = verificar_acesso()
    if redirecionar:
        return redirecionar

    # Conecta-se ao banco de dados SQLite
    conn, c = connect_database(banco)

    if request.method == 'POST':
        # Obtém os campos existentes da tabela
        c.execute(f"PRAGMA table_info({table_name})")
        existing_fields = c.fetchall()

        # Obtém os campos do formulário
        new_fields = []
        field_count = len(request.form) // 2  # Divide por 2 porque cada campo tem um nome e um tipo associado
        for i in range(field_count):
            # Ignora o campo 'id'
            if field_name == 'id':
                continue

            field_name = request.form[f'field_name_{i}']
            field_type = request.form[f'field_type_{i}']
            new_fields.append((field_name, field_type))

        # Verifica se há campos que foram removidos
        removed_fields = [field for field in existing_fields if (field[1], field[2]) not in new_fields]

        # Verifica se há campos que foram adicionados
        added_fields = [field for field in new_fields if (field[0], field[1]) not in existing_fields]

        # Remove os campos da tabela
        for field in removed_fields:
            field_name = field[1]
            c.execute(f"ALTER TABLE {table_name} DROP COLUMN {field_name}")

        # Adiciona os campos na tabela
        for field in added_fields:
            field_name, field_type = field
            c.execute(f"ALTER TABLE {table_name} ADD COLUMN {field_name} {field_type}")

        # Salva as alterações e fecha a conexão com o banco de dados
        conn.commit()
        conn.close()

        return redirect(f'/crud/{table_name}')

    # Obtém as informações da tabela
    c.execute(f"PRAGMA table_info({table_name})")
    table_info = c.fetchall()
    
    # Filtra o campo 'id' da lista de campos existentes
    #table_info = [(name, field_type) for (cid, name, field_type, notnull, dflt_value, pk) in table_info if name != 'id']

    # Fecha a conexão com o banco de dados
    conn.close()

    return render_template('edit_table.html', table_name=table_name, table_info=table_info)

'''
gerar CSV
'''

#--------------------------------------------------------
# Função para obter os dados da tabela para expo
def get_table_data(conn, c, table_name):
    c.execute(f"SELECT * FROM {table_name}")
    table_data = c.fetchall()
    return table_data

# Rota para exportar a tabela em formato CSV
@app.route('/export_table/<table_name>')
def export_table(table_name):
    # verificação de login de acesso
    redirecionar = verificar_acesso()
    if redirecionar:
        return redirecionar

    # Conecta-se ao banco de dados SQLite
    conn, c = connect_database(banco)

    # Obter dados da tabela
    table_data = get_table_data(conn, c, table_name)

    # Obter os nomes das colunas da tabela
    column_names = get_column_names(c, table_name)

    # Fecha a conexão com o banco de dados
    conn.close()

    # Cria um objeto de resposta CSV
    response = Response(stream_with_context(generate_csv(table_data, column_names)))
    response.headers['Content-Disposition'] = 'attachment; filename="' + table_name + '.csv"'

    return response

#--------------------------------------------------------
# Função auxiliar para obter os nomes das colunas da tabela
def get_column_names(c, table_name):
    c.execute(f"PRAGMA table_info({table_name})")
    columns = c.fetchall()
    column_names = [col[1] for col in columns]
    return column_names

#--------------------------------------------------------
# Função auxiliar para gerar o arquivo CSV
def generate_csv(table_data, column_names):
    output = StringIO()
    writer = csv.writer(output, delimiter=';')

    # Escreve o cabeçalho
    writer.writerow(column_names)

    # Escreve os dados da tabela
    for row in table_data:
        writer.writerow(row)

    output.seek(0)
    yield output.getvalue() 
    

'''
Exporta SQL
'''

#----------------------------------------------------------------
# Rota para exportar a tabela em formato SQL
@app.route('/export_table_sql/<table_name>')
def export_table_sql(table_name):
    # verificação de login de acesso
    redirecionar = verificar_acesso()
    if redirecionar:
        return redirecionar

    # Conecta-se ao banco de dados SQLite
    conn, _ = connect_database(banco)

    # Exporta a tabela em SQL
    sql_content = export_table_to_sql(conn, table_name)

    # Fecha a conexão com o banco de dados
    conn.close()

    # Cria um objeto de arquivo em memória
    sql_file = io.BytesIO()

    # Escreve o conteúdo SQL no arquivo em memória
    sql_file.write(sql_content.encode('utf-8'))
    sql_file.seek(0)  # Reposiciona o ponteiro do arquivo no início

    # Envia o arquivo para o cliente como uma resposta para download
    return send_file(sql_file, as_attachment=True, download_name=f"{table_name}.sql")

  
#----------------------------------------------------------------
def export_table_to_sql(conn, table_name):
    cursor = conn.cursor()

    # Obtém o esquema da tabela
    cursor.execute(f"SELECT sql FROM sqlite_master WHERE type='table' AND name='{table_name}'")
    table_schema = cursor.fetchone()[0]

    # Obtém os dados da tabela
    cursor.execute(f"SELECT * FROM {table_name}")
    table_data = cursor.fetchall()

    # Gera o comando INSERT para os dados da tabela
    insert_commands = []
    for row in table_data:
        values = ",".join([f"'{value}'" for value in row])
        insert_command = f"INSERT INTO {table_name} VALUES ({values})"
        insert_commands.append(insert_command)

    # Combina o esquema e os comandos INSERT em um único SQL
    if table_schema.startswith('CREATE TABLE'):
        table_schema = table_schema.replace('CREATE TABLE', 'CREATE TABLE IF NOT EXISTS', 1)
    else:
        return "Invalid table schema."

    sql_content = table_schema + ";\n" + ";\n".join(insert_commands) + ";"

    return sql_content

    
#----------------------------------------------------------------
# Rota para exibir a página de configuração das tabelas
@app.route('/config_tabelas')
def config_tabelas():
    # verificação de login de acesso
    redirecionar = verificar_acesso()
    if redirecionar:
        return redirecionar

    # Conecta-se ao banco de dados SQLite
    conn, c = connect_database(banco)

    # Obtém todas as tabelas do banco de dados
    table_names = get_table_names(conn, c)

    # Fecha a conexão com o banco de dados
    conn.close()

    return render_template('config_tabelas.html', table_names=table_names)


#----------------------------------------------------------------
# IMPORTAR CSV
'''
  IMPORTAR CSV
'''

# Rota para importar um arquivo CSV para a tabela selecionada
@app.route('/import_csv2/<table_name>', methods=['POST'])
def import_csv2(table_name):
    # Verificação de login de acesso
    redirecionar = verificar_acesso()
    if redirecionar:
        return redirecionar

    # Verifica se um arquivo CSV foi enviado na requisição
    if 'file' not in request.files:
        # Nenhum arquivo enviado, redireciona ou exibe uma mensagem de erro
        return redirect('/config_tabelas')  # Ou exiba uma mensagem de erro adequada

    file = request.files['file']

    # Verifica se o arquivo possui um nome e é um arquivo CSV
    if file.filename == '' or not file.filename.endswith('.csv'):
        # Nome de arquivo inválido ou formato de arquivo inválido
        return redirect('/config_tabelas')  # Ou exiba uma mensagem de erro adequada

    # Conecta-se ao banco de dados SQLite
    conn, _ = connect_database(banco)

    try:
        # Abre o arquivo CSV e lê as linhas
        csv_data = csv.reader(file)

        # Ignora a primeira linha se contiver cabeçalho
        if request.form.get('header') == 'ignore':
            next(csv_data)

        # Insere os dados do CSV na tabela
        cursor = conn.cursor()
        for row in csv_data:
            cursor.execute(f"INSERT INTO {table_name} VALUES ({','.join('?' * len(row))})", row)

        # Confirma as alterações no banco de dados
        conn.commit()
    except Exception as e:
        # Trata erros durante a importação
        print(f"Erro durante a importação do CSV: {e}")
        conn.rollback()
        # Redireciona ou exibe uma mensagem de erro adequada

    # Fecha a conexão com o banco de dados
    conn.close()

    # Redireciona ou exibe uma mensagem de sucesso
    return redirect('/config_tabelas')  # Ou exiba uma mensagem de sucesso adequada


#----------------------------------------------------------------
# Rota para importar um arquivo CSV e gerar uma nova tabela
@app.route('/import_csv', methods=['POST'])
def import_csv():
    # Verificação de login de acesso
    redirecionar = verificar_acesso()
    if redirecionar:
        return redirecionar

    # Verifica se um arquivo CSV foi enviado na requisição
    if 'file' not in request.files:
        # Nenhum arquivo enviado, redireciona ou exibe uma mensagem de erro
        return redirect('/config_tabelas')  # Ou exiba uma mensagem de erro adequada

    file = request.files['file']

    # Verifica se o arquivo possui um nome e é um arquivo CSV
    if file.filename == '' or not file.filename.endswith('.csv'):
        # Nome de arquivo inválido ou formato de arquivo inválido
        return redirect('/config_tabelas')  # Ou exiba uma mensagem de erro adequada

    # Remove a extensão .csv do nome do arquivo
    table_name = os.path.splitext(file.filename)[0]

    # Conecta-se ao banco de dados SQLite
    conn, _ = connect_database(banco)

    try:
        # Abre o arquivo CSV e lê as linhas
        csv_data = csv.reader(file)

        # Obtém o cabeçalho do CSV
        header = next(csv_data)

        # Cria uma nova tabela com o nome do arquivo CSV
        cursor = conn.cursor()

        # Cria a tabela com base no cabeçalho do CSV
       #create_table_sql = f"CREATE TABLE IF NOT EXISTS {table_name} ({', '.join([f'"{col}" TEXT' for col in header])})"
        create_table_sql = "CREATE TABLE IF NOT EXISTS " + table_name + " (" + ", ".join(['"' + col + '" TEXT' for col in header]) + ")"
        cursor.execute(create_table_sql)

        # Insere os dados do CSV na tabela
        insert_data_sql = f"INSERT INTO {table_name} VALUES ({', '.join(['?'] * len(header))})"
        for row in csv_data:
            cursor.execute(insert_data_sql, row)

        # Confirma as alterações no banco de dados
        conn.commit()
    except Exception as e:
        # Trata erros durante a importação
        print(f"Erro durante a importação do CSV: {e}")
        conn.rollback()
        # Redireciona ou exibe uma mensagem de erro adequada

    # Fecha a conexão com o banco de dados
    conn.close()

    # Redireciona ou exibe uma mensagem de sucesso
    return redirect('/config_tabelas')  # Ou exiba uma mensagem de sucesso adequada
    
#----------------------------------------------------------------
# Executar script SQL
# Rota para exibir o formulário com o campo <textarea>
@app.route('/executar_sql', methods=['GET'])
def exibir_formulario_sql():
    return render_template('executar_sql.html')

# Rota para executar o código SQL inserido pelo usuário
@app.route('/executar_sql', methods=['POST'])
def executar_sql():
    # verificação de login de acesso
    redirecionar = verificar_acesso()
    if redirecionar:
        return redirecionar

    sql_code = request.form['sql_code']

    # Conecta-se ao banco de dados SQLite
    conn, cursor = connect_database(banco)

    try:
        # Executa o código SQL utilizando a função executescript
        cursor.executescript(sql_code)

        # Confirma as alterações no banco de dados
        conn.commit()

        mensagem = "Código SQL executado com sucesso!"
    except Exception as e:
        # Em caso de erro, faz o rollback e exibe a mensagem de erro
        conn.rollback()
        mensagem = f"Erro ao executar o código SQL: {e}"
    finally:
        # Fecha a conexão com o banco de dados
        conn.close()

    return render_template('executar_sql.html', mensagem=mensagem) 
#----------------------------------------------------------------

#----------------------------------------------------------------
# Rota TEO
#----------------------------------------------------------------
@app.route('/teo', methods=['GET', 'POST'])
def teo():
    # verificação de login de acesso
    redirecionar = verificar_acesso()
    if redirecionar:
        return redirecionar
        
    conn, c = connect_database(banco)

    # Valores padrão
    year_input = datetime.datetime.now().year
    current_month = datetime.datetime.now().month
    user_input = '1'
    
    # Verifica se o mês atual é maior ou igual a setembro (mês 9)
    if current_month >= 9:
        # Se sim, acrescenta 1 ao ano
        year_input = year_input + 1

    if request.method == 'POST':
        # Receber os valores dos inputs
        year_input = request.form['ano']
        user_input = request.form['usuario']

    # Comando SQL com placeholders para os valores
    sql = """
        SELECT strftime('%Y', data) AS ano,
               strftime('%m', data) AS mes,
               SUM(publicacao) AS publicacoes,
               SUM(videos) AS videos,
               SUM(horas) AS horas,
               SUM(revisitas) AS revisitas,
               SUM(estudos) AS estudos
        FROM teo
        WHERE usuario = ? AND data BETWEEN ? AND ?
        GROUP BY mes
        ORDER BY ano, mes
    """

    # Cria uma lista com os valores a serem substituídos nos placeholders
    values = [user_input, f'{int(year_input)-1}-09-01', f'{year_input}-08-31']

    c.execute(sql, values)
    relatorio = c.fetchall()

    # Após obter os resultados do banco de dados
    conn.close()
    
    # Calcular os totais
    total_horas = sum(row[4] for row in relatorio)
    total_revisitas = sum(row[5] for row in relatorio)
    total_estudos = sum(row[6] for row in relatorio)
    
    # Calcular as médias
    num_meses = len(relatorio)
    media_horas = total_horas / num_meses if num_meses > 0 else 0
    media_revisitas = total_revisitas / num_meses if num_meses > 0 else 0
    media_estudos = total_estudos / num_meses if num_meses > 0 else 0

    totais = {'total_horas': total_horas, 'total_revisitas': total_revisitas, 'total_estudos': total_estudos}
    medias = {'media_horas': media_horas, 'media_revisitas': media_revisitas, 'media_estudos': media_estudos}
    
    # Criar um gráfico
    meses_anos = [f"{row[1]}/{row[0]}" for row in relatorio]
    valores_horas = [row[4] for row in relatorio]
    valores_revisitas = [row[5] for row in relatorio]
    valores_estudos = [row[6] for row in relatorio]
    
    # Configurar o gráfico
    plt.figure(figsize=(10, 6))
    plt.plot(meses_anos, valores_horas, label='Horas')
    plt.plot(meses_anos, valores_revisitas, label='Revisitas')
    plt.plot(meses_anos, valores_estudos, label='Estudos')
    plt.xlabel('Mês/Ano')
    plt.ylabel('Valores')
    plt.title('Comparação de Horas, Revisitas e Estudos por Mês/Ano')
    plt.legend()
    plt.xticks(rotation=45, ha='right')  # Rotacionar os rótulos do eixo x para melhor legibilidade
    
    # Salvar o gráfico em um BytesIO para ser incorporado na página HTML
    grafico_stream = BytesIO()
    plt.savefig(grafico_stream, format='png')
    grafico_stream.seek(0)
    grafico_base64 = base64.b64encode(grafico_stream.read()).decode('utf-8')
    plt.close()

   #return render_template('teo.html', relatorio=relatorio, totais=totais, medias=medias, year_input=year_input, user_input=user_input)
    return render_template('teo.html', relatorio=relatorio, totais=totais, medias=medias, year_input=year_input, user_input=user_input, grafico_base64=grafico_base64)
 



#----------------------------------------------------------------
# Sequencia da aplicação flask
#----------------------------------------------------------------
if __name__ == '__main__':
    print('Rodando o APP Flask')
    app.debug = True
    app.run() 
    
