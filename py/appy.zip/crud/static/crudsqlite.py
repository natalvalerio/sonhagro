import sqlite3

# para criar dicionário
def criar_campos():
    print('Vamos definir os CAMPOS DA TABELA. \nNÃO informe o campo ID, o mesmo será criado automaticamente!\n')
    campos = {}
    campos['id'] = 'integer primary key autoincrement' 
    while True:
        chave = input("NOME do Campo (Tecle [ENTER] para sair): ")
        if chave == '':
            break
        valor = input("TIPO do campo (integer, text): ")
        campos[chave] = valor
    print(f"\nCampos criados são: {campos}\n")
    return campos

# Criar uma conexão com o banco de dados
db = input('\nEntre com o nome do BANCO.db: ')
if db == "":
    db = 'banco.db'
print(f'O BANCO selecionado é: {db}\n')

nome_tabela = input('\nEntre com o nome da TABELA: ')
if nome_tabela == "":
    nome_tabela = 'dados'
print(f'A TABELA selecionada é: {nome_tabela}\n')

input('\nTecle enter para prosseguir...\n')

conn = sqlite3.connect(db)

def listar_tabelas(banco):
    print("\n--------------------------------------------")
    # Conectar ao banco de dados
    conn = sqlite3.connect(banco)
    # Obter a lista de tabelas
    cursor = conn.execute("SELECT name FROM sqlite_master WHERE type='table';")
    tabelas = cursor.fetchall()
    # Exibir as tabelas
    if len(tabelas) < 1:
        print(f'\nO banco [{db}] está vasio ou não existe!\n')
    for tabela in tabelas:
        print(tabela[0])
    # Fechar a conexão com o banco de dados
    #conn.close()
    print("--------------------------------------------\n")

def listar_campos_tabela(banco, tabela):
    print("\n--------------------------------------------")
    camp={}
    print(banco)
    print(tabela)
    # Conectar ao banco de dados
    conn = sqlite3.connect(banco)
    # Obter informações sobre a tabela
    cursor = conn.execute(f"SELECT * FROM {tabela} LIMIT 1")
    camposs = [descricao[0] for descricao in cursor.description]
    # Exibir os campos da tabela
    for campo1 in camposs:
        #print(campo1)
        camp[campo1]=''
        print(camp)
        return(camp)
    #Fechar a conexão com o banco de dados
    conn.close()
    print("--------------------------------------------\n")
    
def criar_tabela():
    campos = criar_campos()
    if len(campos.keys()) == 1:
        campos = {'id': 'integer primary key autoincrement', 'nome': 'text', 'celular': 'integer', 'email':'text'}
    print(f'Os campos listados são: {campos}')

    input('\nTecle enter para prosseguir...\n')

    campos_definidos = ", ".join([f"{campo} {tipo}" for campo, tipo in campos.items()])
    conn.execute(f'''
        CREATE TABLE IF NOT EXISTS {nome_tabela} (
            {campos_definidos}
        )
    ''')
    print(f"Tabela {nome_tabela} criada com sucesso.")
    return campos

def listar_registros():
    print("\n--------------------------------------------")
    cursor = conn.execute(f"SELECT * FROM {nome_tabela}")
    resultados = cursor.fetchall()
    for linha in resultados:
        print(linha)
    print("--------------------------------------------\n")

def criar_registro():
    valores = ", ".join([f"'{input(f'Digite o valor para {campo}: ')}'" for campo in campos if campo != 'id'])
    conn.execute(f"INSERT INTO {nome_tabela} ({', '.join(campos)}) VALUES (NULL, {valores})")
    conn.commit()
    print("Registro criado com sucesso.")

def atualizar_registro():
    id_registro = input("Digite o ID do registro que deseja atualizar: ")
    campos_valores = []
    campos = {'ID':'','PROTOCOLO':'','NOME':'','UNIDADE':'','SERVICO':'','DATA':'','ESTATUS':''}
    for campo2 in campos:
        if campo2 == 'id':
            continue
        valor_atual = conn.execute(f"SELECT {campo2} FROM {nome_tabela} WHERE id = {id_registro}").fetchone()[0]
        novo_valor = input(f"Digite o novo valor para {campo2} (deixe em branco para manter o valor atual: {valor_atual}): ")
        if novo_valor == '':
            campos_valores.append(f"{campo2} = '{valor_atual}'")
        else:
            campos_valores.append(f"{campo2} = '{novo_valor}'")
    campos_valores = ", ".join(campos_valores)
    conn.execute(f"UPDATE {nome_tabela} SET {campos_valores} WHERE id = {id_registro}")
    conn.commit()
    print("Registro atualizado com sucesso.")

def deletar_registro():
    id_registro = input("Digite o ID do registro que deseja deletar: ")
    conn.execute(f"DELETE FROM {nome_tabela} WHERE id = {id_registro}")
    conn.commit()
    print("Registro deletado com sucesso.")

def exibir_menu():
    print("\n----- MENU -----\n")
    print(f"1. Criar Tabela [{nome_tabela}]")
    print(f"2. Criar Registro na Tabela [{nome_tabela}]")
    print(f"3. Listar Registro da Tabela [{nome_tabela}]")
    print(f"4. Atualizar Registro na Tabela [{nome_tabela}]")
    print(f"5. Deletar Registro na Tabela [{nome_tabela}]")
    print(f"6. Listar tabelas do Banco [{db}]")
    print(f"7. Escolher Tabela do Banco [{db}]")
    print(f"8. Listar campos da Tabela [{nome_tabela}]")
    print("0. Sair")

def limpar_tela():
    print('\033c', end='')

def pause():
    input('\nPressione [ENTER] para prosseguir...\n')

while True:
    limpar_tela()
    exibir_menu()
    opcao = input("\nEscolha uma opção do menu: ")
    if opcao == "1":
        print("\n----- Criar Tabela -----\n")
        campos = criar_tabela()
    elif opcao == "2":
        print(f"\n----- Criar Registro na Tabela {nome_tabela} -----\n")
        criar_registro()
    elif opcao == "3":
        print(f"\n----- Listar Registro na Tabela {nome_tabela} -----\n")
        limpar_tela()
        listar_registros()
        pause()
    elif opcao == "4":
        print(f"\n----- Atualizar Registro na Tabela {nome_tabela} -----\n")
        atualizar_registro()
    elif opcao == "5":
        print(f"\n----- Deletar Registro na Tabela {nome_tabela} -----\n")
        deletar_registro()
    elif opcao == "6":
        print(f"\n----- Listar Tabelas do banco {db} -----\n")
        listar_tabelas(db)
        pause()
    elif opcao == "7":
        print(f"\n----- Escolher Tabela do Banco {db} -----\n")
        nome_tabela = input(f'Informe qual tabela deseja abrir do banco {db} ')
    elif opcao == "8":
        print(f"\n----- Listar Campos da Tabela {nome_tabela} -----\n")
        camp=listar_campos_tabela(db, nome_tabela)
        print(camp)
        pause()
    elif opcao == "0":
        break
    else:
        print("Opção inválida. Tente novamente.")

# Fechar a conexão com o banco de dados
conn.close()
