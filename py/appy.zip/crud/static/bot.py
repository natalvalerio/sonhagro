# --- bot.py ------
import telebot
import sqlite3
import datetime

#TOKEN = '708859138:AAGQEAnHYD6JQHWRGbTwBQk9uot7lL6-A8I'
TOKEN = '708859138:AAFDbZcsH66QXhhwsSnAi3Vn33uxKQKZvAU'
banco = '../dados/banco.db'
nome_tabela = 'sonhagro'

menu1 = '''
/rural - Atendimento sobre assuntos rurais
/consorcio - Atendimento sobre consórcio
/financiamento - Atendimento sobre financiamentos
/protocolo - Informa status do seu atendimento
'''
menu = '''
/protocolo - Acomanhar o andamento dos seus atendimentos.
'''

# --Procurar protocolo -------------------------------------------------------
def search_protocolo(message):
    usuario = message.from_user.first_name
    protocolo = message.text
    mens = protocolo
    print(f'{usuario}, {protocolo}')
    log_print(usuario, mens)
    # Conectar ao banco de dados e executar a consulta
    conn = sqlite3.connect(banco)
    cursor = conn.cursor()

    cursor.execute(f"SELECT * FROM sonhagro WHERE PROTOCOLO = ?", (protocolo,))
    result = cursor.fetchone()

    if result:
        # Extrair os valores da consulta
        ID,	PROTOCOLO, NOME, CPF, UNIDADE, SERVICO, DATA, GRUPO, COTA, PRAZO, PARCELA, TOTAL, OBS, STATUS, usuario = result

        # Função para verificar valores float
        ToNumber = lambda valor_str: float(valor_str.replace('.', '').replace(',', '.')) if isinstance(valor_str, str) else float(valor_str)

        # Montar a resposta com os valores encontrados
        res = ''
        res = res + f'------------------------- \n'
        res = res + f'PROTOCOLO: {PROTOCOLO} \n'
        res = res + f'NOME: {NOME} \n'
        res = res + f'UNIDADE: {UNIDADE} \n'
        res = res + f'SERVIÇO: {SERVICO} \n'
        res = res + f'DATA: {DATA} \n'
        if len(GRUPO.strip()) > 0:
            res = res + f'GRUPO: {GRUPO} \n'
        if len(COTA.strip()) > 0:
            res = res + f'COTA: {COTA} \n'
        if PRAZO > 0:
            res = res + f'PRAZO: {PRAZO} \n'
        if ToNumber(PARCELA) > 0.0:
            res = res + f'PARCELA: {PARCELA} \n'
        if ToNumber(TOTAL) > 0.0:
            res = res + f'TOTAL: {TOTAL} \n'
        if len(OBS.strip()) > 0:
            res = res + f'OBS: {OBS} \n'
        res = res + f'STATUS: {STATUS} \n'
        res = res + f'-------------------------'

        response = res

        usuario = message.from_user.first_name
        mens = response
        print(f'{usuario}, {response}')
        log_print(usuario, mens)

        bot.reply_to(message, response)
    else:
        print(f'{usuario}, Protocolo não encontrado.')
        bot.reply_to(message, 'Protocolo não encontrado!')
        log_print(usuario, 'Protocolo não encontrado!')
    conn.close()

# -- Salvar log ---------------------------------------------------------------------
def log_print(usuario, mensagem):
    # Obter a data e hora atual
    data_atual = datetime.datetime.now().strftime("%Y-%m-%d")
    hora_atual = datetime.datetime.now().strftime("%H:%M")

    # Conectar ao banco de dados
    conn = sqlite3.connect(banco)
    cursor = conn.cursor()

    # Inserir os campos na tabela log_bot
    cursor.execute("INSERT INTO log_bot (data, hora, usuario, mensagem) VALUES (?, ?, ?, ?)",
                   (data_atual, hora_atual, usuario, mensagem))

    # Confirmar a inserção
    conn.commit()

    # Fechar a conexão com o banco de dados
    conn.close()

bot = telebot.TeleBot(TOKEN)

# -----------------------------------------------------------------------
# Comandos /start, /rural, /consorcio, /financiamento
@bot.message_handler(commands=['start', 'rural', 'consorcio', 'financiamento'])
def handle_commands(message):
    command = message.text[1:]  # Remove o "/" do comando
    usuario = message.from_user.first_name
    mens = message.text
    print(f'{usuario}, {menu}')
    print(f'{usuario}, {mens}')
    log_print(usuario, mens)
    if command == 'start':
        bot.reply_to(message, 'Bem-vindo ao Bot Sonhagro: \n'+menu)
    elif command == 'rural':
        bot.reply_to(message, 'Rural')
    elif command == 'consorcio':
        bot.reply_to(message, 'Consórcios')
    elif command == 'financiamento':
        bot.reply_to(message, 'Financiamentos')

# -----------------------------------------------------------------------
# Comando /protocolo
@bot.message_handler(commands=['protocolo'])
def handle_protocolo(message):
    usuario = message.from_user.first_name
    mens = message.text
    print(f'{usuario}, {menu}')
    print(usuario+', '+message.text)
    print('Digite o protocolo')
    log_print(usuario, mens + ' - Digite o protocolo')
    bot.reply_to(message, 'Digite o protocolo:')
    bot.register_next_step_handler(message, search_protocolo)

# -----------------------------------------------------------------------
# Inserir dados teocráticos
@bot.message_handler(commands=['teo'])
def handle_teo(message):
    # Obter a data atual no formato YYYY-MM-DD
    data = datetime.datetime.now().strftime("%Y-%m-%d")
    bot.send_message(message.chat.id, f"Já peguei a Data: {data}.")
    bot.send_message(message.chat.id, f"Agora pode começar a inserir as demais informações: \nPublicações:")
    print(f'{ask_publicacao} \n {data}')
    bot.register_next_step_handler(message, ask_publicacao, data)

def ask_publicacao(message, data):
    # Salvar a quantidade de Publicacao e pedir a próxima informação
    bot.send_message(message.chat.id, "Vídeos:")
    print(f'{ask_videos} \n {data} \n {message.text}')
    bot.register_next_step_handler(message, ask_videos, data, message.text)

def ask_videos(message, data, publicacao):
    # Salvar a quantidade de Videos e pedir a próxima informação
    bot.send_message(message.chat.id, "Horas:")
    print(f'{ask_horas} \n {data} \n {publicacao} \n {message.text}')
    bot.register_next_step_handler(message, ask_horas, data, publicacao, message.text)

def ask_horas(message, data, publicacao, videos):
    # Salvar a quantidade de Horas e pedir a próxima informação
    bot.send_message(message.chat.id, "Revisitas:")
    print(f'{ask_revisitas} \n {data} \n {publicacao} \n {videos} \n {message.text}')
    bot.register_next_step_handler(message, ask_revisitas, data, publicacao, videos, message.text)

def ask_revisitas(message, data, publicacao, videos, horas):
    # Salvar a quantidade de Revisitas e pedir a próxima informação
    bot.send_message(message.chat.id, "Estudos:")
    print(f'{ask_estudos} \n {data} \n {publicacao} \n {videos} \n {horas} \n {message.text}')
    bot.register_next_step_handler(message, ask_estudos, data, publicacao, videos, horas, message.text)

def ask_estudos(message, data, publicacao, videos, horas, revisitas):
    # Salvar a quantidade de Estudos e pedir a próxima informação
    bot.send_message(message.chat.id, "Observações:")
    print(f'{ask_obs} \n {data} \n {publicacao} \n {videos} \n {horas} \n {revisitas} \n {message.text}')
    bot.register_next_step_handler(message, ask_obs, data, publicacao, videos, horas, revisitas, message.text)

def ask_obs(message, data, publicacao, videos, horas, revisitas, estudos):
    # Salvar a Observacao e pedir a próxima informação
    bot.send_message(message.chat.id, "Número do Usuario:")
    print(f'{ask_usuario} \n {data} \n {publicacao} \n {videos} \n {horas} \n {revisitas} \n {estudos} \n {message.text}')
    bot.register_next_step_handler(message, ask_usuario, data, publicacao, videos, horas, revisitas, estudos, message.text)

def ask_usuario(message, data, publicacao, videos, horas, revisitas, estudos, obs):
    # Salvar a Observacao e pedir a próxima informação
    usuario = message.text
    bot.send_message(message.chat.id, "Salvando os dados na tabela TEO...")
    print(f'{insert_into_teo} \n {data} \n {publicacao} \n {videos} \n {horas} \n {revisitas} \n {estudos} \n {obs} \n {message.text}')
    insert_into_teo(message, data, publicacao, videos, horas, revisitas, estudos, obs, message.text)

def insert_into_teo(message, data, publicacao, videos, horas, revisitas, estudos, obs, usuario):
    # Conectar ao banco de dados e inserir os valores na tabela TEO
    conn = sqlite3.connect(banco)
    cursor = conn.cursor()

    cursor.execute("INSERT INTO TEO (data, Publicacao, Videos, Horas, Revisitas, Estudos, Obs, usuario) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                   (data, publicacao, videos, horas, revisitas, estudos, obs, usuario))

    # Confirmar a inserção
    conn.commit()

    # Fechar a conexão com o banco de dados
    conn.close()

    # Enviar uma mensagem de confirmação ao usuário
    bot.send_message(message.chat.id, "Dados inseridos com sucesso na tabela TEO!")
# -----------------------------------------------------------------------
@bot.message_handler(commands=['teo2'])
def handle_teo2(message):
    bot.send_message(message.chat.id, "https://natalvalerio.pythonanywhere.com/teo")
    return


# -----------------------------------------------------------------------
# Função handler para comandos não reconhecidos
@bot.message_handler(func=lambda message: True)
def handle_unknown_command(message):
    usuario = message.from_user.first_name
    mens = message.text
    log_print(usuario, mens+' - Não localizei esse comando.')
    bot.reply_to(message, 'Não localizei esse comando.')
    print(usuario+', '+mens+' - Não localizei esse comando.')

# -----------------------------------------------------------------------
print('Iniciando bot...')
bot.polling()
