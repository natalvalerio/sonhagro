import smtplib
from email.message import EmailMessage
from datetime import datetime

def envio(usuario):
    # Obtendo a data e hora atuais
    agora = datetime.now()
    
    # Armazenando cada componente em variáveis separadas
    ano = agora.year
    mes = agora.month
    dia = agora.day
    hora = agora.hour
    minuto = agora.minute
    segundo = agora.second
    data = f'{dia}/{mes}/{ano}'
    horario = f'{hora}:{minuto}'


    # Configurações do servidor de e-mail
    smtp_server = 'mail.sonhagro.com.br' #:2080
    smtp_port = 587 # 25 465 587
    smtp_username = 'natalino.valerio@sonhagro.com.br'
    smtp_password = 'V@lerio123'
    
    # Criando a mensagem de e-mail
    msg = EmailMessage()
    msg['Subject'] = f'Confirmação de Login - {usuario}'
    msg['From'] = smtp_username
    msg['To'] = 'nvalerio059@gmail.com'
    msg.set_content(f'Parabêns {usuario}, você logou corretamente! \nÀs {horario} do dia {data}')
    
    try: 
        # Conectando-se ao servidor de e-mail e enviando a mensagem
        with smtplib.SMTP(smtp_server, smtp_port) as server:
            server.starttls()
            server.login(smtp_username, smtp_password)
            server.send_message(msg)
        print('Seu email foi enviado com sucesso!')    
    except:
        print('Houve um erro e não foi possível enviar seu e-mail!')
        