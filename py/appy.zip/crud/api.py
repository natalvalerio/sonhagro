from flask import Flask, request, jsonify
import sqlite3
from flask_cors import CORS  # Importa a extensão CORS

app = Flask(__name__)
CORS(app, origins="*") # Configuração do CORS

# Caminho para o banco de dados
banco = '../dados/banco.db'

# Função para conectar ao banco de dados
def conectar_bd():
    return sqlite3.connect(banco)
    
# Rota para servir arquivos estáticos (HTML, imagens, etc.) a partir de uma pasta
@app.route('/static/<path:filename>')
def servir_arquivos_estaticos(filename):
    return send_from_directory('static', filename)

# Rota inicial
@app.route('/', methods=['GET'])
def home():
    return 'Bem-vindo à API!'

# Rota inicial
@app.route('/api', methods=['GET'])
def api_home():
    return 'Bem-vindo à API!'

# Rota para executar comandos SQL
@app.route('/api/sql', methods=['POST'])
def executar_sql():
    try:
        dados = request.get_json()
        comando_sql = dados.get('sql')
        conexao = conectar_bd()
        cursor = conexao.cursor()
        cursor.execute(comando_sql)
        conexao.commit()
        conexao.close()
        resposta = {'mensagem': 'Comando SQL executado com sucesso!'}
        app.logger.info("Resposta: %s", resposta)  # Adicione esta linha
        return jsonify(resposta)
    except Exception as e:
        resposta = {'erro': str(e)}
        app.logger.error("Erro: %s", resposta)  # Adicione esta linha
        return jsonify(resposta)


# Rota para adicionar registro
@app.route('/api/add/<table>', methods=['POST'])
def adicionar_registro(table):
    try:
        dados = request.get_json()
        campos = ', '.join(dados.keys())
        valores = ', '.join([f'"{v}"' for v in dados.values()])
        comando_sql = f'INSERT INTO {table} ({campos}) VALUES ({valores})'
        conexao = conectar_bd()
        cursor = conexao.cursor()
        cursor.execute(comando_sql)
        conexao.commit()
        conexao.close()
        return jsonify({'mensagem': 'Registro adicionado com sucesso!'})
    except Exception as e:
        return jsonify({'erro': str(e)})

@app.route('/api/select/<table>/<campo>/<busca>', methods=['GET'])
def selecionar(table, campo=None, busca=None):
    try:
        conexao = conectar_bd()
        cursor = conexao.cursor()
        if campo is None or busca is None:
            # Chame a função selecionar do arquivo api.py sem especificar campo e busca
            cursor.execute(f'SELECT * FROM {table}')
        else:
            # Chame a função selecionar do arquivo api.py passando todos os parâmetros
            cursor.execute(f'SELECT * FROM {table} where {campo} = "{busca}"')
 
        registros = cursor.fetchall()

        # Obtendo os nomes das colunas
        colunas = [descricao[0] for descricao in cursor.description]

        # Criando uma lista de dicionários com os nomes das colunas
        resultados = []
        for registro in registros:
            resultado_dict = {}
            for i, coluna in enumerate(colunas):
                resultado_dict[coluna] = registro[i]
            resultados.append(resultado_dict)

        conexao.close()

        return jsonify(resultados)

    except Exception as e:
        return jsonify({'erro': str(e)})


# Rota para atualizar registro
@app.route('/api/update/<table>', methods=['PUT'])
def atualizar_registro(table):
    try:
        dados = request.get_json()
        set_clause = ', '.join([f'{campo} = "{valor}"' for campo, valor in dados.items()])
        where_clause = f'WHERE id = {dados["id"]}'  # Assumindo que há um campo "id"
        comando_sql = f'UPDATE {table} SET {set_clause} {where_clause}'
        conexao = conectar_bd()
        cursor = conexao.cursor()
        cursor.execute(comando_sql)
        conexao.commit()
        conexao.close()
        return jsonify({'mensagem': 'Registro atualizado com sucesso!'})
    except Exception as e:
        return jsonify({'erro': str(e)})

# Rota para deletar registro
@app.route('/api/del/<table>', methods=['DELETE'])
def deletar_registro(table):
    try:
        dados = request.get_json()
        where_clause = f'WHERE id = {dados["id"]}'  # Assumindo que há um campo "id"
        comando_sql = f'DELETE FROM {table} {where_clause}'
        conexao = conectar_bd()
        cursor = conexao.cursor()
        cursor.execute(comando_sql)
        conexao.commit()
        conexao.close()
        return jsonify({'mensagem': 'Registro deletado com sucesso!'})
    except Exception as e:
        return jsonify({'erro': str(e)})

if __name__ == '__main__':
    app.run(debug=True)
