# Embracon - José Israel
[Embracon](https://www.convertmais.com.br/AdminConvertMais/ConvertMaisWeb/login/)

jose.izael@parceiroembracon.com.br

N7BI!id7e@

# Embracon - Carangola - Kelly
>https://www.convertmais.com.br/AdminConvertMais/ConvertMaisWeb/login/
>joseaugusto.sonhagro@parceiroembracon.com.br
>9T61@lu@M@

# Embracon - Mariane Brito - Auriflama
>https://www.convertmais.com.br/AdminConvertMais/ConvertMaisWeb/login/
>mariane.brito@parceiroembracon.com.br
>W!43@7XzH@

# Embracon - Natani Mendes
>https://www.convertmais.com.br/AdminConvertMais/ConvertMaisWeb/login/
>natani.mendes@parceiroembracon.com.br
>!Bj5kgx0t!

# Embracon - Maria Auxiliadora
>https://www.convertmais.com.br/AdminConvertMais/ConvertMaisWeb/login/
>auxiliadora.assis@parceiroembracon.com.br
>SR4@0Q@1!3

# Embracon - 
>https://www.convertmais.com.br/AdminConvertMais/ConvertMaisWeb/login/
>@parceiroembracon.com.br
>senha

# Embracon - 
>https://www.convertmais.com.br/AdminConvertMais/ConvertMaisWeb/login/
>@parceiroembracon.com.br
>senha