var nome="Natalino";
var idade=41;
alert("Teste")